# Tutorias y Asesorias - Grupo 3

Repositorio del modulo de Tutorias y Asesorias.

El proyecto contiene:

- `tutoriasyasesorias/`: primera version del frontend estatico.
- `tutoriasyasesorias2/tutoriasyasesorias/`: frontend con separacion en modelos, servicios, UI y validadores.
- `tutorias-backend/`: backend REST funcional con Node.js, Express y MySQL.

## Backend implementado

La tarea de backend se encuentra en:

```text
tutorias-backend/
```

Incluye:

- CRUD de tutorias/solicitudes de tutorias.
- Rutas Express.
- Controlador.
- Servicio con validaciones.
- Modelo con consultas SQL.
- Conexion MySQL con `mysql2`.
- Respuestas JSON estandarizadas.
- Middleware global de errores.
- Script SQL de tabla y datos iniciales.
- Coleccion Postman exportable.
- Documentacion minima de endpoints.

## Como ejecutar el backend

```bash
cd tutorias-backend
npm install
copy .env.example .env
npm run seed
npm run dev
```

Base URL:

```text
http://localhost:3000
```

Endpoints principales:

| Metodo | Ruta | Descripcion |
| --- | --- | --- |
| GET | `/` | Informacion general de la API |
| GET | `/api/tutorias` | Listar tutorias |
| GET | `/api/tutorias/:id` | Obtener una tutoria |
| POST | `/api/tutorias` | Crear una tutoria |
| PUT | `/api/tutorias/:id` | Actualizar una tutoria |
| DELETE | `/api/tutorias/:id` | Eliminar una tutoria |

Para mas detalles revisar `tutorias-backend/README.md`.
