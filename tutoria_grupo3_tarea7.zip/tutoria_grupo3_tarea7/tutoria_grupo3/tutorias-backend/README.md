# Backend - Modulo de Tutorias y Asesorias

Backend REST con Node.js, Express y MySQL para implementar el CRUD del modulo de tutorias/solicitudes de tutorias.

## Arquitectura

```text
tutorias-backend/
├── src/
│   ├── app.js
│   ├── config/db.js
│   ├── controllers/tutoria.controller.js
│   ├── database/schema.sql
│   ├── database/seed.js
│   ├── middlewares/errorHandler.js
│   ├── models/tutoria.model.js
│   ├── routes/tutoria.routes.js
│   ├── services/tutoria.service.js
│   └── utils/responses.js
├── .env.example
├── package.json
└── README.md
```

La separacion por capas queda asi:

- Rutas: definen los endpoints HTTP.
- Controlador: recibe `req`, llama al servicio y devuelve JSON.
- Servicio: valida datos y aplica reglas de negocio.
- Modelo/acceso a datos: ejecuta consultas SQL con MySQL2.
- Middleware: centraliza errores.
- Utils: estandariza respuestas JSON.

## Instalacion

```bash
npm install
copy .env.example .env
npm run seed
npm run dev
```

En Windows PowerShell tambien puedes crear el `.env` con:

```powershell
Copy-Item .env.example .env
```

## Variables de entorno

```env
PORT=3000
NODE_ENV=development
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=
DB_NAME=am_grupo3
```

## Tabla principal

La tabla se llama `tutorias`.

Campos principales:

- `id`: identificador autoincremental.
- `docente_tutor`: nombre del docente o tutor.
- `materia`: materia solicitada.
- `horario`: horario de la tutoria.
- `estado`: `Pendiente`, `Aprobada`, `Rechazada`, `Cancelada` o `Finalizada`.
- `descripcion`: detalle opcional.

## Endpoints

| Metodo | Ruta | Descripcion |
| --- | --- | --- |
| GET | `/` | Informacion general de la API |
| GET | `/api/tutorias` | Listar tutorias |
| GET | `/api/tutorias/:id` | Obtener una tutoria por id |
| POST | `/api/tutorias` | Crear una tutoria |
| PUT | `/api/tutorias/:id` | Actualizar una tutoria |
| DELETE | `/api/tutorias/:id` | Eliminar una tutoria |

Filtros disponibles:

```http
GET /api/tutorias?estado=Pendiente
GET /api/tutorias?materia=Bases
```

## Validaciones

- `docente_tutor` es obligatorio, tipo texto, minimo 3 y maximo 100 caracteres.
- `materia` es obligatoria, tipo texto, minimo 3 y maximo 100 caracteres.
- `horario` es obligatorio, tipo texto, minimo 5 y maximo 120 caracteres.
- `estado` debe ser uno de: `Pendiente`, `Aprobada`, `Rechazada`, `Cancelada`, `Finalizada`.
- `descripcion` es opcional y maximo 255 caracteres.

## Ejemplo POST

Request:

```json
{
  "docente_tutor": "Pedro Ramirez",
  "materia": "Bases de Datos",
  "horario": "Viernes 10:00-12:00",
  "estado": "Pendiente",
  "descripcion": "Repaso de normalizacion y consultas SQL."
}
```

Response:

```json
{
  "ok": true,
  "message": "Tutoria creada correctamente",
  "data": {
    "id": 6,
    "docente_tutor": "Pedro Ramirez",
    "materia": "Bases de Datos",
    "horario": "Viernes 10:00-12:00",
    "estado": "Pendiente",
    "descripcion": "Repaso de normalizacion y consultas SQL.",
    "creado_en": "2026-06-05T23:00:00.000Z",
    "actualizado_en": "2026-06-05T23:00:00.000Z"
  }
}
```

## Ejemplo error de validacion

```json
{
  "ok": false,
  "message": "Datos de tutoria invalidos",
  "details": [
    "El campo docente_tutor es obligatorio",
    "El campo estado debe ser uno de: Pendiente, Aprobada, Rechazada, Cancelada, Finalizada"
  ]
}
```

## Pruebas con Postman

Importa el archivo `postman/tutorias-backend.postman_collection.json`.

Base URL:

```text
http://localhost:3000
```

Para POST y PUT usar `Body -> raw -> JSON`.
