const express = require('express');
const cors = require('cors');
require('dotenv').config();

const tutoriaRoutes = require('./routes/tutoria.routes');
const errorHandler = require('./middlewares/errorHandler');
const { error } = require('./utils/responses');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

app.get('/', (req, res) => {
  res.json({
    ok: true,
    message: 'API del modulo de tutorias y asesorias - Grupo 3',
    endpoints: {
      tutorias: '/api/tutorias'
    }
  });
});

app.use('/api/tutorias', tutoriaRoutes);

app.use((req, res) => {
  return error(res, 'Ruta no encontrada', 404);
});

app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`Servidor ejecutandose en http://localhost:${PORT}`);
});

module.exports = app;
