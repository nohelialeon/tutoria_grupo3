const tutoriaService = require('../services/tutoria.service');
const { success } = require('../utils/responses');

async function list(req, res, next) {
  try {
    const tutorias = await tutoriaService.getAll({
      estado: req.query.estado,
      materia: req.query.materia
    });

    return success(res, tutorias, 'Tutorias obtenidas correctamente', 200, {
      total: tutorias.length
    });
  } catch (err) {
    return next(err);
  }
}

async function getOne(req, res, next) {
  try {
    const tutoria = await tutoriaService.getById(req.params.id);
    return success(res, tutoria, 'Tutoria encontrada');
  } catch (err) {
    return next(err);
  }
}

async function create(req, res, next) {
  try {
    const tutoria = await tutoriaService.create(req.body);
    return success(res, tutoria, 'Tutoria creada correctamente', 201);
  } catch (err) {
    return next(err);
  }
}

async function update(req, res, next) {
  try {
    const tutoria = await tutoriaService.update(req.params.id, req.body);
    return success(res, tutoria, 'Tutoria actualizada correctamente');
  } catch (err) {
    return next(err);
  }
}

async function remove(req, res, next) {
  try {
    await tutoriaService.remove(req.params.id);
    return success(res, null, 'Tutoria eliminada correctamente');
  } catch (err) {
    return next(err);
  }
}

module.exports = {
  list,
  getOne,
  create,
  update,
  remove
};
