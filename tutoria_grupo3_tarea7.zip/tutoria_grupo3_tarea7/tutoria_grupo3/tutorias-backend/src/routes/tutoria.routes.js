const express = require('express');
const tutoriaController = require('../controllers/tutoria.controller');

const router = express.Router();

router.get('/', tutoriaController.list);
router.get('/:id', tutoriaController.getOne);
router.post('/', tutoriaController.create);
router.put('/:id', tutoriaController.update);
router.delete('/:id', tutoriaController.remove);

module.exports = router;
