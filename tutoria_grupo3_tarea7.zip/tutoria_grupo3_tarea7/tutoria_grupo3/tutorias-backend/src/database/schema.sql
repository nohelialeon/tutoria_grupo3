CREATE TABLE IF NOT EXISTS tutorias (
  id INT AUTO_INCREMENT PRIMARY KEY,
  docente_tutor VARCHAR(100) NOT NULL,
  materia VARCHAR(100) NOT NULL,
  horario VARCHAR(120) NOT NULL,
  estado ENUM('Pendiente', 'Aprobada', 'Rechazada', 'Cancelada', 'Finalizada') NOT NULL DEFAULT 'Pendiente',
  descripcion VARCHAR(255) NULL,
  creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  actualizado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT INTO tutorias (docente_tutor, materia, horario, estado, descripcion) VALUES
('Juan Perez', 'Programacion Web', 'Lunes 08:00-10:00', 'Pendiente', 'Solicitud para reforzar fundamentos de backend con Node.js.'),
('Maria Gomez', 'Matematicas Discretas', 'Martes 10:00-12:00', 'Aprobada', 'Repaso de grafos y relaciones.'),
('Carlos Ruiz', 'Bases de Datos', 'Miercoles 14:00-16:00', 'Pendiente', 'Asesoria sobre consultas SQL y normalizacion.'),
('Ana Lopez', 'Fisica', 'Jueves 09:00-11:00', 'Finalizada', 'Revision de ejercicios de movimiento.'),
('Luis Silva', 'Ingenieria de Software', 'Viernes 15:00-17:00', 'Rechazada', 'El horario solicitado no esta disponible.');
