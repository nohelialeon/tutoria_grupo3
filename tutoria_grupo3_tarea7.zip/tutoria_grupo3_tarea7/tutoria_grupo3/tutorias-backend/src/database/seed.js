const fs = require('fs');
const path = require('path');
const pool = require('../config/db');

async function seed() {
  const schemaPath = path.join(__dirname, 'schema.sql');
  const statements = fs
    .readFileSync(schemaPath, 'utf8')
    .split(';')
    .map((statement) => statement.trim())
    .filter(Boolean);

  for (const statement of statements) {
    await pool.query(statement);
  }

  console.log('Base de datos preparada correctamente');
  await pool.end();
}

seed().catch(async (err) => {
  console.error('Error al preparar la base de datos:', err.message);
  await pool.end();
  process.exit(1);
});
