const tutoriaModel = require('../models/tutoria.model');

const ESTADOS_VALIDOS = ['Pendiente', 'Aprobada', 'Rechazada', 'Cancelada', 'Finalizada'];

function createHttpError(statusCode, message, details = null) {
  const error = new Error(message);
  error.statusCode = statusCode;
  error.details = details;
  return error;
}

function validateId(id) {
  const numericId = Number(id);

  if (!Number.isInteger(numericId) || numericId <= 0) {
    throw createHttpError(400, 'El id debe ser un numero entero positivo');
  }

  return numericId;
}

function validateTutoriaPayload(payload, isUpdate = false) {
  const errors = [];
  const data = {
    docente_tutor: typeof payload.docente_tutor === 'string' ? payload.docente_tutor.trim() : '',
    materia: typeof payload.materia === 'string' ? payload.materia.trim() : '',
    horario: typeof payload.horario === 'string' ? payload.horario.trim() : '',
    estado: typeof payload.estado === 'string' ? payload.estado.trim() : '',
    descripcion: typeof payload.descripcion === 'string' ? payload.descripcion.trim() : null
  };

  if (!data.docente_tutor) {
    errors.push('El campo docente_tutor es obligatorio');
  } else if (data.docente_tutor.length < 3 || data.docente_tutor.length > 100) {
    errors.push('El campo docente_tutor debe tener entre 3 y 100 caracteres');
  }

  if (!data.materia) {
    errors.push('El campo materia es obligatorio');
  } else if (data.materia.length < 3 || data.materia.length > 100) {
    errors.push('El campo materia debe tener entre 3 y 100 caracteres');
  }

  if (!data.horario) {
    errors.push('El campo horario es obligatorio');
  } else if (data.horario.length < 5 || data.horario.length > 120) {
    errors.push('El campo horario debe tener entre 5 y 120 caracteres');
  }

  if (!data.estado && !isUpdate) {
    data.estado = 'Pendiente';
  }

  if (!data.estado) {
    errors.push('El campo estado es obligatorio');
  } else if (!ESTADOS_VALIDOS.includes(data.estado)) {
    errors.push(`El campo estado debe ser uno de: ${ESTADOS_VALIDOS.join(', ')}`);
  }

  if (data.descripcion && data.descripcion.length > 255) {
    errors.push('El campo descripcion no debe superar los 255 caracteres');
  }

  if (errors.length) {
    throw createHttpError(400, 'Datos de tutoria invalidos', errors);
  }

  return data;
}

async function getAll(filters) {
  return tutoriaModel.findAll(filters);
}

async function getById(id) {
  const numericId = validateId(id);
  const tutoria = await tutoriaModel.findById(numericId);

  if (!tutoria) {
    throw createHttpError(404, 'Tutoria no encontrada');
  }

  return tutoria;
}

async function create(payload) {
  const data = validateTutoriaPayload(payload);
  return tutoriaModel.create(data);
}

async function update(id, payload) {
  const numericId = validateId(id);
  await getById(numericId);
  const data = validateTutoriaPayload(payload, true);
  return tutoriaModel.update(numericId, data);
}

async function remove(id) {
  const numericId = validateId(id);
  await getById(numericId);
  return tutoriaModel.remove(numericId);
}

module.exports = {
  ESTADOS_VALIDOS,
  getAll,
  getById,
  create,
  update,
  remove
};
