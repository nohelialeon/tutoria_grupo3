const { error } = require('../utils/responses');

function errorHandler(err, req, res, next) {
  if (res.headersSent) {
    return next(err);
  }

  const status = err.statusCode || 500;
  const message = err.message || 'Error interno del servidor';

  return error(res, message, status, err.details);
}

module.exports = errorHandler;
