function success(res, data, message = 'Operacion realizada correctamente', status = 200, extra = {}) {
  return res.status(status).json({
    ok: true,
    message,
    ...extra,
    data
  });
}

function error(res, message = 'Error interno del servidor', status = 500, details = null) {
  const body = {
    ok: false,
    message
  };

  if (details) {
    body.details = details;
  }

  return res.status(status).json(body);
}

module.exports = {
  success,
  error
};
