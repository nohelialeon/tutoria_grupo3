const pool = require('../config/db');

async function findAll(filters = {}) {
  const where = [];
  const values = [];

  if (filters.estado) {
    where.push('estado = ?');
    values.push(filters.estado);
  }

  if (filters.materia) {
    where.push('materia LIKE ?');
    values.push(`%${filters.materia}%`);
  }

  const sql = `
    SELECT id, docente_tutor, materia, horario, estado, descripcion, creado_en, actualizado_en
    FROM tutorias
    ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
    ORDER BY id DESC
  `;

  const [rows] = await pool.query(sql, values);
  return rows;
}

async function findById(id) {
  const [rows] = await pool.query(
    `SELECT id, docente_tutor, materia, horario, estado, descripcion, creado_en, actualizado_en
     FROM tutorias
     WHERE id = ?`,
    [id]
  );

  return rows[0] || null;
}

async function create(tutoria) {
  const [result] = await pool.query(
    `INSERT INTO tutorias (docente_tutor, materia, horario, estado, descripcion)
     VALUES (?, ?, ?, ?, ?)`,
    [
      tutoria.docente_tutor,
      tutoria.materia,
      tutoria.horario,
      tutoria.estado,
      tutoria.descripcion || null
    ]
  );

  return findById(result.insertId);
}

async function update(id, tutoria) {
  const [result] = await pool.query(
    `UPDATE tutorias
     SET docente_tutor = ?, materia = ?, horario = ?, estado = ?, descripcion = ?
     WHERE id = ?`,
    [
      tutoria.docente_tutor,
      tutoria.materia,
      tutoria.horario,
      tutoria.estado,
      tutoria.descripcion || null,
      id
    ]
  );

  if (result.affectedRows === 0) {
    return null;
  }

  return findById(id);
}

async function remove(id) {
  const [result] = await pool.query('DELETE FROM tutorias WHERE id = ?', [id]);
  return result.affectedRows > 0;
}

module.exports = {
  findAll,
  findById,
  create,
  update,
  remove
};
