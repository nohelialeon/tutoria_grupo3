/**
 * @file errorHandler.js
 * @description Middleware global de manejo de errores.
 * Captura errores de controladores y devuelve respuestas JSON uniformes.
 */

'use strict';

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  const status  = err.status  || 500;
  const message = err.message || 'Error interno del servidor.';

  if (status >= 500) {
    console.error('[ERROR]', err);
  }

  res.status(status).json({ ok: false, message });
}

module.exports = errorHandler;
