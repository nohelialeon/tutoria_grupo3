/**
 * @file app.js
 * @description Punto de entrada del servidor Express.
 * Configura middlewares globales, monta rutas y arranca el servidor.
 */

'use strict';

require('dotenv').config();

const express      = require('express');
const cors         = require('cors');
const { verificarConexion } = require('./config/db');
const tutoriaRoutes  = require('./routes/tutoria.routes');
const errorHandler   = require('./middlewares/errorHandler');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── Middlewares globales ───────────────────────────────────────────────────
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ── Ruta de salud ──────────────────────────────────────────────────────────
app.get('/', (req, res) => {
  res.json({
    ok:      true,
    modulo:  'Tutorías y Asesorías – Grupo 3',
    version: '1.0.0',
    endpoints: {
      tutorias: '/api/tutorias',
    },
  });
});

// ── Rutas de la API ────────────────────────────────────────────────────────
app.use('/api/tutorias', tutoriaRoutes);

// ── 404 ────────────────────────────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ ok: false, message: `Ruta ${req.method} ${req.path} no encontrada.` });
});

// ── Error global ──────────────────────────────────────────────────────────
app.use(errorHandler);

// ── Inicio ────────────────────────────────────────────────────────────────
async function iniciar() {
  try {
    await verificarConexion();
    app.listen(PORT, () => {
      console.log(`🚀  Servidor escuchando en http://localhost:${PORT}`);
      console.log(`📋  GET /api/tutorias → lista de tutorías`);
    });
  } catch (err) {
    console.error('❌  No se pudo iniciar el servidor:', err.message);
    process.exit(1);
  }
}

iniciar();

module.exports = app;
