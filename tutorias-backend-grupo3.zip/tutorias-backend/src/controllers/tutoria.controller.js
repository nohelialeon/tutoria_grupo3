/**
 * @file tutoria.controller.js
 * @description Controladores HTTP para el recurso /api/tutorias.
 * Recibe la petición, delega al servicio y devuelve la respuesta JSON.
 */

'use strict';

const TutoriaService = require('../services/tutoria.service');

// GET /api/tutorias
async function getAll(req, res, next) {
  try {
    const { materia, estado, modalidad } = req.query;
    const tutorias = await TutoriaService.listarTutorias({ materia, estado, modalidad });
    res.json({
      ok:     true,
      total:  tutorias.length,
      data:   tutorias,
    });
  } catch (err) {
    next(err);
  }
}

// GET /api/tutorias/:id
async function getOne(req, res, next) {
  try {
    const tutoria = await TutoriaService.obtenerTutoria(Number(req.params.id));
    res.json({ ok: true, data: tutoria });
  } catch (err) {
    next(err);
  }
}

// POST /api/tutorias
async function create(req, res, next) {
  try {
    const nueva = await TutoriaService.crearTutoria(req.body);
    res.status(201).json({ ok: true, message: 'Tutoría creada correctamente.', data: nueva });
  } catch (err) {
    next(err);
  }
}

// PUT /api/tutorias/:id
async function update(req, res, next) {
  try {
    const actualizada = await TutoriaService.actualizarTutoria(Number(req.params.id), req.body);
    res.json({ ok: true, message: 'Tutoría actualizada correctamente.', data: actualizada });
  } catch (err) {
    next(err);
  }
}

// DELETE /api/tutorias/:id
async function remove(req, res, next) {
  try {
    await TutoriaService.eliminarTutoria(Number(req.params.id));
    res.json({ ok: true, message: 'Tutoría eliminada correctamente.' });
  } catch (err) {
    next(err);
  }
}

module.exports = { getAll, getOne, create, update, remove };
