/**
 * @file tutoria.service.js
 * @description Capa de servicio: aplica reglas de negocio antes de
 * delegar las operaciones de datos al modelo.
 *
 * Reglas de negocio implementadas:
 *  RN-01 Estado inicial siempre "Disponible" al crear una tutoría.
 *  RN-02 Solo se permiten materias del catálogo oficial.
 *  RN-03 El número de cupos debe estar entre 1 y 20.
 *  RN-04 No se puede crear una tutoría con estado "Cancelada" directamente.
 */

'use strict';

const TutoriaModel = require('../models/tutoria.model');

const MATERIAS_VALIDAS = [
  'Programación Web', 'Matemáticas Discretas', 'Bases de Datos',
  'Física', 'Ingeniería de Software', 'Redes',
];

const MODALIDADES_VALIDAS  = ['Presencial', 'Virtual', 'Híbrida'];
const ESTADOS_VALIDOS      = ['Disponible', 'Reservada', 'Cancelada', 'Completada'];

// ── helpers de validación ──────────────────────────────────────────────────
function validarCampos({ docente, materia, horario, modalidad, cupos, estado }) {
  if (!docente || docente.trim().length < 3)
    return 'El nombre del docente debe tener al menos 3 caracteres.';

  if (!materia || !MATERIAS_VALIDAS.includes(materia))          // RN-02
    return `Materia inválida. Opciones: ${MATERIAS_VALIDAS.join(', ')}.`;

  if (!horario || horario.trim().length < 5)
    return 'El horario es obligatorio (ej: Lunes 10:00–12:00).';

  if (modalidad && !MODALIDADES_VALIDAS.includes(modalidad))
    return `Modalidad inválida. Opciones: ${MODALIDADES_VALIDAS.join(', ')}.`;

  if (cupos !== undefined) {
    const n = Number(cupos);
    if (!Number.isInteger(n) || n < 1 || n > 20)                // RN-03
      return 'Los cupos deben ser un número entero entre 1 y 20.';
  }

  if (estado && !ESTADOS_VALIDOS.includes(estado))
    return `Estado inválido. Opciones: ${ESTADOS_VALIDOS.join(', ')}.`;

  return null; // sin errores
}

// ── operaciones CRUD ──────────────────────────────────────────────────────

async function listarTutorias(filtros) {
  return TutoriaModel.findAll(filtros);
}

async function obtenerTutoria(id) {
  const t = await TutoriaModel.findById(id);
  if (!t) throw { status: 404, message: `Tutoría con id=${id} no encontrada.` };
  return t;
}

async function crearTutoria(datos) {
  const error = validarCampos(datos);
  if (error) throw { status: 400, message: error };

  // RN-01: estado siempre "Disponible" al crear
  // RN-04: no se puede crear con estado "Cancelada"
  datos.estado = 'Disponible';

  return TutoriaModel.create(datos);
}

async function actualizarTutoria(id, cambios) {
  await obtenerTutoria(id); // lanza 404 si no existe

  // Validar solo los campos que se envían
  if (Object.keys(cambios).length > 0) {
    const error = validarCampos({ ...cambios });
    // Si falta docente/materia/horario en cambios parciales, ignorar esos checks
    const errorFiltrado = (error && error.includes('obligatorio')) ? null : error;
    if (errorFiltrado) throw { status: 400, message: errorFiltrado };
  }

  return TutoriaModel.update(id, cambios);
}

async function eliminarTutoria(id) {
  await obtenerTutoria(id);
  return TutoriaModel.remove(id);
}

module.exports = { listarTutorias, obtenerTutoria, crearTutoria, actualizarTutoria, eliminarTutoria };
