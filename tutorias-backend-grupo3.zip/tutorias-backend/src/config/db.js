/**
 * @file db.js
 * @description Pool de conexiones a MariaDB/MySQL usando mysql2/promise.
 * Se exporta el pool para ser utilizado por los modelos.
 */

'use strict';

const mysql = require('mysql2/promise');
require('dotenv').config();

const pool = mysql.createPool({
  host:            process.env.DB_HOST,
  port:            Number(process.env.DB_PORT) || 3306,
  user:            process.env.DB_USER,
  password:        process.env.DB_PASSWORD,
  database:        process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit:      0,
  timezone:        'Z',
});

/**
 * Verifica la conexión al inicio de la aplicación.
 * Lanza un error si no puede conectarse.
 */
async function verificarConexion() {
  const conn = await pool.getConnection();
  console.log(`✅  Conectado a MariaDB → ${process.env.DB_HOST}/${process.env.DB_NAME}`);
  conn.release();
}

module.exports = { pool, verificarConexion };
