/**
 * @file tutoria.model.js
 * @description Capa de acceso a datos para la tabla `tutorias`.
 * Todas las funciones devuelven promesas.
 */

'use strict';

const { pool } = require('../config/db');

/**
 * Obtiene todas las tutorías con filtros opcionales.
 * @param {{ materia?: string, estado?: string, modalidad?: string }} filtros
 * @returns {Promise<Tutoria[]>}
 */
async function findAll({ materia, estado, modalidad } = {}) {
  let sql    = 'SELECT * FROM tutorias WHERE 1=1';
  const params = [];

  if (materia)   { sql += ' AND materia   = ?'; params.push(materia);   }
  if (estado)    { sql += ' AND estado    = ?'; params.push(estado);    }
  if (modalidad) { sql += ' AND modalidad = ?'; params.push(modalidad); }

  sql += ' ORDER BY creado_en ASC';
  const [rows] = await pool.query(sql, params);
  return rows;
}

/**
 * Busca una tutoría por su ID.
 * @param {number} id
 * @returns {Promise<Tutoria|null>}
 */
async function findById(id) {
  const [rows] = await pool.query('SELECT * FROM tutorias WHERE id = ?', [id]);
  return rows[0] ?? null;
}

/**
 * Crea una nueva tutoría.
 * @param {{ docente, materia, horario, modalidad, cupos, estado, descripcion }} datos
 * @returns {Promise<Tutoria>} Registro creado (con ID generado).
 */
async function create(datos) {
  const { docente, materia, horario, modalidad = 'Presencial',
          cupos = 5, estado = 'Disponible', descripcion = null } = datos;

  const [result] = await pool.query(
    `INSERT INTO tutorias (docente, materia, horario, modalidad, cupos, estado, descripcion)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [docente, materia, horario, modalidad, cupos, estado, descripcion]
  );
  return findById(result.insertId);
}

/**
 * Actualiza los campos de una tutoría.
 * @param {number} id
 * @param {object} cambios
 * @returns {Promise<Tutoria|null>}
 */
async function update(id, cambios) {
  const campos  = ['docente', 'materia', 'horario', 'modalidad', 'cupos', 'estado', 'descripcion'];
  const sets    = [];
  const valores = [];

  campos.forEach(c => {
    if (cambios[c] !== undefined) {
      sets.push(`${c} = ?`);
      valores.push(cambios[c]);
    }
  });

  if (sets.length === 0) return findById(id);

  valores.push(id);
  await pool.query(`UPDATE tutorias SET ${sets.join(', ')} WHERE id = ?`, valores);
  return findById(id);
}

/**
 * Elimina una tutoría por ID.
 * @param {number} id
 * @returns {Promise<boolean>}
 */
async function remove(id) {
  const [result] = await pool.query('DELETE FROM tutorias WHERE id = ?', [id]);
  return result.affectedRows > 0;
}

module.exports = { findAll, findById, create, update, remove };
