/**
 * @file tutoria.routes.js
 * @description Rutas del recurso /api/tutorias.
 */

'use strict';

const { Router } = require('express');
const ctrl       = require('../controllers/tutoria.controller');

const router = Router();

router.get   ('/',    ctrl.getAll);   // GET    /api/tutorias
router.get   ('/:id', ctrl.getOne);   // GET    /api/tutorias/:id
router.post  ('/',    ctrl.create);   // POST   /api/tutorias
router.put   ('/:id', ctrl.update);   // PUT    /api/tutorias/:id
router.delete('/:id', ctrl.remove);   // DELETE /api/tutorias/:id

module.exports = router;
