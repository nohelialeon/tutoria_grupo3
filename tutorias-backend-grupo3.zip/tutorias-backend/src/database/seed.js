/**
 * @file seed.js
 * @description Script autónomo: crea la tabla y carga los datos semilla.
 * Uso: npm run seed
 */

'use strict';

require('dotenv').config();
const fs   = require('fs');
const path = require('path');
const { pool } = require('../config/db');

async function seed() {
  console.log('🌱  Iniciando seed de la base de datos…');

  const sql = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');

  // Separar sentencias por ";"
  const sentencias = sql
    .split(';')
    .map(s => s.trim())
    .filter(s => s.length > 0 && !s.startsWith('--'));

  const conn = await pool.getConnection();
  try {
    for (const stmt of sentencias) {
      await conn.query(stmt);
      console.log(`  ✔  ${stmt.slice(0, 60).replace(/\n/g, ' ')}…`);
    }
    console.log('\n✅  Seed completado correctamente.');
  } catch (err) {
    console.error('❌  Error durante el seed:', err.message);
    process.exit(1);
  } finally {
    conn.release();
    pool.end();
  }
}

seed();
