-- ============================================================
--  Módulo: Tutorías y Asesorías – Grupo 3
--  Base de datos: am_grupo3 (MariaDB en grupofmo.com)
--  Archivo: schema.sql
-- ============================================================

-- Tabla principal
CREATE TABLE IF NOT EXISTS tutorias (
  id         INT          UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  docente    VARCHAR(120) NOT NULL,
  materia    VARCHAR(120) NOT NULL,
  horario    VARCHAR(80)  NOT NULL  COMMENT 'Ej: Lunes 10:00–12:00',
  modalidad  ENUM('Presencial','Virtual','Híbrida') NOT NULL DEFAULT 'Presencial',
  cupos      TINYINT      UNSIGNED NOT NULL DEFAULT 5
             COMMENT 'Máximo 20 cupos (RN-04)',
  estado     ENUM('Disponible','Reservada','Cancelada','Completada')
             NOT NULL DEFAULT 'Disponible',
  descripcion TEXT,
  creado_en  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT chk_cupos CHECK (cupos BETWEEN 1 AND 20)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Datos semilla (5 registros mínimos) ─────────────────────────────────────
INSERT INTO tutorias (docente, materia, horario, modalidad, cupos, estado, descripcion)
VALUES
  ('Carlos Gómez',   'Matemáticas Discretas', 'Lunes 08:00–10:00',    'Presencial', 10, 'Disponible', 'Práctica de grafos, lógica proposicional y combinatoria.'),
  ('Ana Silva',      'Programación Web',       'Martes 14:00–16:00',   'Virtual',     8, 'Disponible', 'HTML5, CSS3 y JavaScript moderno. Introducción a frameworks.'),
  ('Luis Fernando',  'Bases de Datos',         'Miércoles 10:00–12:00','Presencial',  6, 'Reservada',  'Diseño de esquemas ER, normalización y consultas SQL avanzadas.'),
  ('María López',    'Física',                 'Jueves 07:00–09:00',   'Híbrida',    12, 'Disponible', 'Cinemática, dinámica y ejercicios de aplicación.'),
  ('Ana Silva',      'Ingeniería de Software', 'Viernes 15:00–17:00',  'Virtual',     5, 'Disponible', 'Patrones de diseño, UML y buenas prácticas de desarrollo.'),
  ('Elena Rojas',    'Redes',                  'Lunes 16:00–18:00',    'Presencial',  8, 'Reservada',  'Modelo OSI, TCP/IP, subnetting y configuración de equipos.'),
  ('Carlos Gómez',   'Matemáticas Discretas', 'Jueves 10:00–12:00',   'Virtual',     7, 'Disponible', 'Árboles, recurrencias y análisis de algoritmos.'),
  ('Luis Fernando',  'Programación Web',       'Viernes 08:00–10:00',  'Presencial', 10, 'Disponible', 'Introducción a React: componentes, hooks y estado.');
